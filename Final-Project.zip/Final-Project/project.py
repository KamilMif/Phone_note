import tkinter as tk
from tkinter import ttk
import sqlite3

# Создадим объект
class Employee:
    def __init__(self, fio, phone, email, salary):
        self.fio = fio
        self.phone = phone
        self.email = email
        self.salary = salary

# Установим заголовок главного окна приложения в "Список сотрудников компании"
class EmployeeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Список сотрудников компании")

# Создадим виджет "Treeview" с указанными столбцами и отобразим его на главном окне приложения
        self.tree = ttk.Treeview(self.root)
        self.tree["columns"] = ("fio", "phone", "email", "salary")
        self.tree.pack()

# Установим заголовок первого столбца с идентификатором "#0" и текстом "ID"
        self.tree.heading("#0", text="ID")
        self.tree.column("#0", width=50)

# Зададим заголовок столбца с идентификатором "fio" и текстом "ФИО"
        self.tree.heading("fio", text="ФИО")
        self.tree.column("fio", width=150)

# Зададим заголовок столбца с идентификатором "phone" и текстом "Номер телефона"
        self.tree.heading("phone", text="Номер телефона")
        self.tree.column("phone", width=100)

# Установим заголовок столбца с идентификатором "email" и текстом "Email"
        self.tree.heading("email", text="Email")
        self.tree.column("email", width=150)

# Зададим заголовок столбца с идентификатором "salary" и текстом "Заработная плата"
        self.tree.heading("salary", text="Заработная плата")
        self.tree.column("salary", width=100)

# Свяжем кнопку с текстом "Добавить сотрудника" на главном окне приложения и свяжем её с методом "add_emloyee"
        self.add_employee_btn = ttk.Button(self.root, text="Добавить сотрудника", command=self.add_employee)
        self.add_employee_btn.pack()

# Создадим кнопку с текстом "Изменить сотрудника" на главном окне приложения и свяжем её с методом "update_employee"
        self.update_employee_btn = ttk.Button(self.root, text="Изменить сотрудника", command=self.update_employee)
        self.update_employee_btn.pack()

# Создадим кнопку с текстом "Удалить сотрудника" на главном окне приложения и свяжем её с методом "delete_emloyee"
        self.delete_employee_btn = ttk.Button(self.root, text="Удалить сотрудника", command=self.delete_employee)
        self.delete_employee_btn.pack()

# Создадим кнопку с текстом "Поиск по ФИО" на главном окне приложения и свяжем её с методом "search_employee"
        self.search_employee_btn = ttk.Button(self.root, text="Поиск по ФИО", command=self.search_employee)
        self.search_employee_btn.pack()

# Создадим объект соединения с базой данных SQLite, используя файл "employees.db" в качестве базы данных
        self.conn = sqlite3.connect("employees.db")
        self.cursor = self.conn.cursor()

# Вызывем метод "create_table()" у объекта(класса) и создадим таблицу "employees" в базе данных
        self.create_table()
        self.load_employees()

# Создадим таблицу "employees" в базе данных
    def create_table(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fio TEXT,
                phone TEXT,
                email TEXT,
                salary INTEGER
            )
        """)
        self.conn.commit()

# Создадим метод "add_employee" в классе, который запрашивает у пользователя данные о новом сотруднике, создаёт объект "emloyee" класса "Emloyee" с этими данными, а затем сохраняет эту информацию в базе данных в таблице "emloyees"
    def add_employee(self):
        fio = input("Введите ФИО: ")
        phone = input("Введите номер телефона: ")
        email = input("Введите адрес электронной почты: ")
        salary = input("Введите заработную плату: ")

# Создадим объект "employee" класса "Employee" с атрибутами "fio", "phone", "email" и "salary", переданными в качестве аргументов конструктора класса
        employee = Employee(fio, phone, email, salary)

# Выполним операцию вставки новой записи в таблицу "employees" базы данных
        self.cursor.execute("INSERT INTO employees (fio, phone, email, salary) VALUES (?, ?, ?, ?)",
                            (employee.fio, employee.phone, employee.email, employee.salary))
        self.conn.commit()

# Вызывем метод класса (self), который загружает список всех сотрудников из базы данных и сохраняет их в переменной
        self.load_employees()

# Представим метод класса (self), который запрашивает у пользователя ввод идентификатора(id) сотрудника, данные которого нужно обновить в базе данных
    def update_employee(self):
        id = input("Введите ID сотрудника, которого хотите обновить: ")

# Выполним SQL-запрос к базе данных, чтобы получить данные о сотруднике с определённым идентификатором(id)
        self.cursor.execute("SELECT * FROM employees WHERE id=?", (id,))
        employee_data = self.cursor.fetchone()

# Если переменная emloyee_data не равна None, то программа запрашивает у пользователя новые значения для ФИО, номера телефона, адреса электронной почты и заработной платы
        if employee_data is not None:
            fio = input("Введите новое ФИО: ")
            phone = input("Введите новый номер телефона: ")
            email = input("Введите новый адрес электронной почты: ")
            salary = input("Введите новую заработную плату: ")

# Создадим объект класса Employee, используя переданные значения 
            employee = Employee(fio, phone, email, salary)

# Обновим данные сотрудника в таблице "employees" в базе данных, используя переданные значения
            self.cursor.execute("UPDATE employees SET fio=?, phone=?, email=?, salary=? WHERE id=?",
                                (employee.fio, employee.phone, employee.email, employee.salary, id))
            self.conn.commit()

            self.load_employees()
        else:
            print("Сотрудник с таким ID не найден")

# Запросим у пользователя ввод ID сотрудника, которого нужно удалить из таблицы "employees" в базе данных
    def delete_employee(self):
        id = input("Введите ID сотрудника, которого хотите удалить: ")

# Выполним запрос к базе данных на выборку записей из таблицы "employees"
        self.cursor.execute("SELECT * FROM employees WHERE id=?", (id,))
        employee_data = self.cursor.fetchone()

# Запросим у пользователя потдверждение на удаление сотрудника из базы данных
        if employee_data is not None:
            confirm = input("Вы уверены, что хотите удалить этого сотрудника? (yes/no)")

# Представим метод для удаления сотрудника из базы данных по его ID
            if confirm.lower() == "yes":
                self.cursor.execute("DELETE FROM employees WHERE id=?", (id,))
                self.conn.commit()

                self.load_employees()
        else:
            print("Сотрудник с таким ID не найден")

# Представим метод для поиска сотрудника в базе данных по ФИО
    def search_employee(self):
        fio = input("Введите ФИО сотрудника для поиска: ")

# Выполним запрос к базе данных для выборки всех записей из таблицы "emloyees"
        self.cursor.execute("SELECT * FROM employees WHERE fio=?", (fio,))
        employee_data = self.cursor.fetchall()

# Выполним запрос к базе данных для выборки всех записей из таблицы "employees" и выведем информацию о каждом сотруднике на экран
        if employee_data:
            for employee in employee_data:
                print("ID:", employee[0])
                print("ФИО:", employee[1])
                print("Номер телефона:", employee[2])
                print("Email:", employee[3])
                print("Заработная плата:", employee[4])
                print("")
        else:
            print("Сотрудник с таким ФИО не найден")

# Удалим все элементы из виджета "tree"
    def load_employees(self):
        self.tree.delete(*self.tree.get_children())

# Выполним запрос к базе данных и выбирем все записи из таблицы "employees"
        self.cursor.execute("SELECT * FROM employees")
        employees = self.cursor.fetchall()

# Добавим данные об сотрудниках в виде строк
        for employee in employees:
            self.tree.insert("", "end", text=employee[0], values=(employee[1], employee[2], employee[3], employee[4]))

# Создадим экземпляр класса tk.Tk()
root = tk.Tk()
app = EmployeeApp(root)
root.mainloop()